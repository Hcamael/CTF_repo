import sys
import subprocess
from cStringIO import StringIO
def usage(argv):
    print "usage: %s INPUT OUTPUT" % argv[0]
    sys.exit(1)

def main(argv):
    if len(argv) != 3:
        usage(argv)
    inFile = file(argv[1], "rb")
    outFile = file(argv[2], "wb")
    while True:
        chunk = inFile.read(8)
        chunkLen = len(chunk)
        chunk = chunk.ljust(8, chr(8-chunkLen))
        p = subprocess.Popen(["./engineTest", "./cp", "./ip", "/dev/stdin", "./op"], stdout=subprocess.PIPE,stdin=subprocess.PIPE)
        p.stdin.write(chunk)
        chunkOut = p.stdout.read(1024)
        assert len(chunk) == 8
        outFile.write(chunkOut)
        if chunkLen != 8:#Lask chunk
            break
    outFile.close()
        
        
    print "Finish!"
if __name__ == "__main__":
    main(sys.argv)
    
    


