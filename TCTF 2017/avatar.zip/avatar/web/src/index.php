<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

define("ROOT", "/");
define("ROUTER_SITE", __DIR__);
define("ROUTER_ROOT", __DIR__ . '/../');
define("USER_PROFILE", ROOT . '/tmp/profiles/');
define("TPL_DIR", ROUTER_ROOT . "/templates/");

define("DEFAULT_AVATAR", ROUTER_SITE . "/img/default.png");
define("DEFAULT_TZ", "+00:00");

require ROUTER_ROOT . '/vendor/autoload.php';
require ROUTER_SITE . '/db.php';
require ROUTER_SITE . '/config.php';



$app = new \Slim\App(["setting" => $config]);
$container = $app->getContainer();

$container['db'] = function ($c) {
 	$db = $c['setting']['db'];
	$mysql = new depend\mysql($db);
	return $mysql;
};

$container['sess'] = function ($c) {
	$sess = new depend\sess();
	return $sess;
};

$container['profile'] = function ($c) {
	$profile = new depend\profile();
	return $profile;
};


Twig_Autoloader::register(true);
$container['twig'] = new Twig_Environment(new Twig_Loader_String());
$container['view'] = function ($container) {
    $view = new \Slim\Views\Twig(TPL_DIR);
    $view->addExtension(new \Slim\Views\TwigExtension(
        $container['router'],
        $container['request']->getUri()
    ));
    return $view;
};
\depend\Security();


$app->map(["GET", "POST"], '/connect', function (Request $request, Response $response) {
	if ($request->isGet()) {
		if ($this->sess->get('user'))
			return $response->withStatus(301)->withHeader('Location', '/');

		$this->view->render($response, 'login.tpl');
		return $response;
	}

	$username = $request->getParam('user');
	$password = $request->getParam('pass');
	if (!$username or !$password) {
		$response->write("error");
		return $response;
	}

	$this->db->table('users');
	$this->db->where("username", "=", $username);

	if ($user = $this->db->select()) {
		if ($user['password'] === md5($password))
		{
			$this->sess->set('user', $user);
			$this->profile->setdir($user['username']);
			$tz = $this->profile->getTZ();
			$this->view->render($response, 'index.tpl', array(
				'success'=> 1,
				'info' => 'Login Success',
				'username' => $username,
				"tz" => $tz
				));
			return $response;
		}
		else
		{
			$this->view->render($response, 'login.tpl', array(
				'fail'=> 1,
				'info' => 'Password Wrong'
			));
			return $response;
		}
	}
	else {
		$this->view->render($response, 'login.tpl', array(
			'fail'=> 1,
			'info' => 'No Such User'
		));
		return $response;
	}
})->setName('login');


$app->get('/logout', function (Request $request, Response $response) {
	$this->sess->destory();
	return $response->withStatus(301)->withHeader('Location', '/');
})->setName('logout');


$app->map(['GET', 'POST'], '/register', function (Request $request, Response $response) {
	if ($request->isGet()) {
		$this->view->render($response, 'register.tpl');
		return $response;
	}

	$username = $request->getParam('user');
	$password = $request->getParam('pass');
	if (!$username or !$password or strstr($username, "./")) {
		$this->view->render($response, 'register.tpl', array(
			'fail'=> 1,
			'info' => 'user & pass format error'
		));
		return $response;
	}

	$this->db->table('users');
	$this->db->where("username", "=", $this->db->filter($username));
	if ($this->db->select()) {
		$this->view->render($response, 'register.tpl', array(
			'fail'=> 1,
			'info' => 'Duplicate User'
		));
		return $response;
	}

	$this->db->insert($username, md5($password), DEFAULT_AVATAR);
	$this->profile->setdir($username);

	$this->view->render($response, 'login.tpl', array(
		'success'=> 1,
		'info' => 'Register Success'
	));
	return $response;
})->setName('register');


$app->post('/setTZ', function(Request $request, Response $response) {
	$user = $this->sess->get('user');
	if ($user == Null)
		return $response->withStatus(301)->withHeader('Location', '/');

	$this->profile->setdir($user['username']);

	$tz = $request->getParam('data');
	if ($tz == Null) {
		$response->write("error");
		return $response;
	}

	if (strlen($tz) != 6) {
		$response->write("tz format error");
		return $response;		
	}

	$this->profile->setTZ($tz);
	$response->write("update tz success");
	return $response;
})->setName('setTZ');

$app->post('/setAvatar', function(Request $request, Response $response) {
	$user = $this->sess->get('user');
	if ($user == Null)
		return $response->withStatus(301)->withHeader('Location', '/');

	$this->profile->setdir($user['username']);
	if (! isset($_FILES['avatar'])) {
		$response->write("avatar format error");
		return $response;
	}
	$this->db->table('users');
	$this->db->where('username', '=', $user['username']);
	$this->db->update('avatar', $_FILES['avatar']['name']);
	$this->profile->setAvatar($_FILES['avatar']['name'], $_FILES['avatar']['tmp_name']);
	$response->write("update avatar success");
})->setName('setAvatar');

$app->get('/getAvatar', function(Request $request, Response $response) {
	$user = $this->sess->get('user');
	if ($user == Null)
		return $response->withStatus(301)->withHeader('Location', '/');

	$this->profile->setdir($user['username']);

	$avatar = $this->profile->getAvatar($user['avatar']);

	$response->write($avatar);

	return $response->withStatus(200)->withHeader('Content-Type', 'image/jpeg');
})->setName('getAvatar');


$app->get('/', function (Request $request, Response $response) {
	if ($this->sess->get('user')) {
		$user = $this->sess->get('user');
		$this->profile->setdir($user['username']);
		$tz = $this->profile->getTZ();
		return $this->view->render($response, "/index.tpl", array(
				"username" => $user['username'],
				"tz" => $tz
			));
	}

	return $this->view->render($response, "/login.tpl");
})->setName('index');


$app->run();
