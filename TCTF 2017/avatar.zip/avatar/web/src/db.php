<?php
namespace depend;

class mysql{
	public $conn;
	private $table;
	private $where = [];
	private $limit = '';
	public function __construct($c) {
		$this->addConnection($c);
	}

	public function addConnection($c) {
		$this->conn = mysqli_connect($c['host'], $c['user'], $c['pass']);
		mysqli_select_db($this->conn, $c['dbname']);
	}
	public function table($table) {
		$this->table = $table;
	}

	public function where($key = '', $operate = '', $value = '') {
		$this->where[] = sprintf("%s %s %s", $key, $operate, $this->quote($value));

	}

	public function select($value = '*') {
		if(count($this->where) == 0) {
			$sql = sprintf("SELECT %s FROM %s ", $value, $this->table);
		}
		else {
			$where = implode(' AND ', $this->where);
			$sql = sprintf("SELECT %s FROM %s WHERE %s", $value, $this->table, $where);
		}
		$sql .= $this->limit;
		$result = mysqli_query($this->conn, $sql);
		if(!$result)
			return null;
		return mysqli_fetch_assoc($result);
	}

	public function insert() {
		$args_list = array_map(array($this, 'filter'), func_get_args());
		$sql = sprintf("INSERT INTO %s VALUE ('%s')", $this->table, implode("', '", $args_list));
		$result = mysqli_query($this->conn, $sql);
		return $result;
	}

	public function update($key, $value) {
		$args_list = array_map(array($this, 'filter'), func_get_args());
		if(count($this->where) == 0) {
			$sql = sprintf("UPDATE %s set %s='%s'", $this->table, $args_list[0], $args_list[1]);
		}
		else {
			$where = implode(' AND ', $this->where);
			$sql = sprintf("UPDATE %s set %s='%s' WHERE %s", $this->table, $args_list[0], $args_list[1], $where);
		}
		$result = mysqli_query($this->conn, $sql);
	}

	public function filter($value) {
		return $this->conn->real_escape_string($value);
	}

	public function quote($value) {
		return sprintf('\'%s\'', $value);
	}
}

class sess{
	public function __construct() {
		session_start();
	}

	public function set($key, $value) {
		$_SESSION[$key] = $value;
	}

	public function get($key) {
		return isset($_SESSION[$key]) ? $_SESSION[$key] : null;
	}

	public function destory() {
		session_destroy();
	}
}

class profile {
	private $dir;

	private $profile_savepath;

	public function __construct() {
		$this->profile_savepath = USER_PROFILE;
		chdir(ROOT);
		if(! is_dir($this->profile_savepath))
			mkdir($this->profile_savepath, 0777) or die("Mkdir Error");
	}

	public function setdir($dir) {
		$dir = escapeshellcmd($dir);
		if(! is_dir($this->profile_savepath . $dir))
			mkdir($this->profile_savepath . $dir, 0777) or die("Mkdir Error");
		$this->dir = $dir;
	}

	public function getdir() {
		$dir = $this->dir;
		if ($dir == Null) {
			$dir = md5( rand() . time());
			$this->setdir($dir);
		}
		return $this->dir;
	}

	public function setTZ($tz) {
		exec(sprintf("echo %s > %s%s/TZ", $tz, $this->profile_savepath, $this->getdir()));
	}

	public function getTZ() {
		$file = $this->profile_savepath . $this->getdir() . "/TZ";

		if(is_file($file)) {
			$content = file_get_contents($file);
			unlink($file);
			return $content;
		}
		else
			return DEFAULT_TZ;
	}

	public function setAvatar($filename, $tmpname) {
		$file = $this->profile_savepath . $this->getdir() . "/". $filename;
		move_uploaded_file($tmpname, $file);
	}

	public function getAvatar($avatar) {
		$file = $this->profile_savepath . $this->getdir() . "/". $avatar;
		if(is_file($file))
			return file_get_contents($file);
		else
			return file_get_contents(DEFAULT_AVATAR);
	}
}

function Security()
{
	if (filter_shell($_GET))
			die("Potential Hack");

	if ($_SERVER['REQUEST_METHOD'] === "POST") {
		if (filter_shell($_POST))
			die("Potential Hack");
	}
}

function filter_shell($var)
{
	foreach($var as $key => $value) {
		if( is_array($value) && filter_shell($value))
			return true;
		if( preg_match("/[;$`&]/i", $key . $value))
			return true;
	}
	return false;
}
