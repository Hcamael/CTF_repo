<?php
$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$config['db']['host']   = "localhost";
$config['db']['user']   = "0ops";
$config['db']['pass']   = "123456";
$config['db']['dbname'] = "0ops";
