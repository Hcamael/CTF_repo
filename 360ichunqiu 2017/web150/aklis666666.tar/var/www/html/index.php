<?php
session_start();
if (!isset($_SESSION['path'])){
  $addtime=time().mt_rand(100000,999999); 
  $filename = $addtime.".txt";
  $textdir = "./path/".$addtime.".txt";
  $_SESSION['path'] = $textdir;
  $_SESSION['filename'] = $filename;
  echo file_get_contents('index.txt');
}else{
  $textdir  = $_SESSION['path'];
}
if(isset($_REQUEST['code'])){
	file_put_contents($textdir,$_REQUEST['code']);
	header("Location: index.php");
}else{
	echo file_get_contents($textdir);
}
?>
<form method="post" action="">
	<input name="code" >
	<button type="submit">edit</button>
</form>


