<?php
    highlight_file(__FILE__);
    $dir = 'tmp/'; 
    if(!file_exists($dir))
	mkdir($dir);   
    chdir($dir);
    if(!isset($_GET['shell'])){
	phpinfo();
	exit();
    }
    $shell = $_GET['shell'];
    for ( $i=0; $i<count($shell); $i++ ){
        if ( !preg_match('/^\w+$/', $shell[$i]) )
            exit();
    } 
    session_start();
    $path = $_SESSION['path'];
    $shell =  str_replace('path','/'.$path,implode(" ",$shell));
    echo $shell;
    exec("/bin/hence " . $shell);
?>
